SELECT
  DATE_FORMAT (date, '%Y-%m') AS month,
  SUM(amount) as total_amount,
  COUNT(
    CASE
      WHEN amount < 1000000 THEN amount
      ELSE NULL
    END
  ) AS num_transac_below_1m,
  COUNT(
    CASE
      WHEN amount >= 1000000
      AND amount < 5000000 THEN amount
      ELSE NULL
    END
  ) AS num_transac_between_1m_5m,
  COUNT(
    CASE
      WHEN amount >= 5000000 THEN amount
      ELSE NULL
    END
  ) AS num_transac_above_5m
FROM
  deals
GROUP BY
  month
ORDER BY
  month;