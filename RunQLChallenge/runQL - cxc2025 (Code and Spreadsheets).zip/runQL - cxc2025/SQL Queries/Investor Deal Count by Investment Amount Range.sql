SELECT 
  di.investorName,
  SUM(CASE WHEN de.amount < 1000000 THEN 1 ELSE 0 END) AS '< 1 million',
  SUM(CASE WHEN de.amount BETWEEN 1000000 AND 5000000 THEN 1 ELSE 0 END) AS '1-5 million',
  SUM(CASE WHEN de.amount > 5000000 THEN 1 ELSE 0 END) AS '> 5 million'
FROM 
  dealInvestor di
  JOIN deals de ON di.dealId = de.id
GROUP BY 
  di.investorName;