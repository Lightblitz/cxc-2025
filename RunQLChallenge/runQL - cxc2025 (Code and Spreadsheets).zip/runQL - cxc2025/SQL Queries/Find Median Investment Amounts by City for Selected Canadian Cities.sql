SELECT
  i.city,
  AVG(subquery.amount) AS median_amount
FROM
  deals d
  JOIN investors i ON d.investors = i.investorName
  JOIN (
    SELECT
      d.amount,
      i.city,
      ROW_NUMBER() OVER (
        PARTITION BY
          i.city
        ORDER BY
          d.amount
      ) AS row_num,
      COUNT(*) OVER (
        PARTITION BY
          i.city
      ) AS total_count
    FROM
      deals d
      JOIN investors i ON d.investors = i.investorName
    WHERE
      i.city IN (
        'Calgary',
        'Montreal',
        'Ottawa',
        'Toronto',
        'Vancouver',
        'Waterloo'
      )
  ) AS subquery ON i.city = subquery.city
WHERE
  subquery.row_num IN (
    FLOOR((subquery.total_count + 1) / 2),
    FLOOR((subquery.total_count + 2) / 2)
  )
GROUP BY
  i.city;