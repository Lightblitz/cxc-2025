WITH
  ranked_deals AS (
    SELECT
      e.province,
      d.primaryTag,
      COUNT(*) AS deal_count,
      ROW_NUMBER() OVER (
        PARTITION BY
          e.province
        ORDER BY
          COUNT(*) DESC
      ) AS deal_rank
    FROM
      deals d
      JOIN ecosystems e ON d.ecosystemName = e.ecosystemName
    WHERE
      e.province IS NOT NULL
    GROUP BY
      e.province,
      d.primaryTag
  )
SELECT
  province,
  primaryTag,
  deal_count
FROM
  ranked_deals
WHERE
  deal_rank <= 5;