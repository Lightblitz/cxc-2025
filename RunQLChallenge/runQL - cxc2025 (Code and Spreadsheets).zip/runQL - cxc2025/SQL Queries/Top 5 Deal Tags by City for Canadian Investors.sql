SELECT
  city,
  primaryTag,
  deal_count
FROM
  (
    SELECT
      i.city,
      d.primaryTag,
      COUNT(d.id) AS deal_count,
      ROW_NUMBER() OVER (
        PARTITION BY
          i.city
        ORDER BY
          COUNT(d.id) DESC
      ) as rn
    FROM
      deals d
      JOIN dealInvestor di ON d.id = di.dealId
      JOIN investors i ON di.investorId = i.id
    WHERE
      i.city IN (
        'Calgary',
        'Toronto',
        'Vancouver',
        'Ottawa',
        'Montreal',
        'Waterloo',
        'Waterloo Region',
        'Waterloo-Kitchener'
      )
    GROUP BY
      i.city,
      d.primaryTag
  ) as t
WHERE
  rn <= 5
ORDER BY
  city,
  deal_count DESC;