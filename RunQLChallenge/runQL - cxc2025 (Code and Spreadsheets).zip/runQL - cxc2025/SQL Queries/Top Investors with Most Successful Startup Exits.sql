SELECT
  di.investorName,
  COUNT(DISTINCT c.id) AS successful_exits
FROM
  dealInvestor di
  JOIN companies c ON di.companyId = c.id
WHERE
  c.acquiringCompany IS NOT NULL
  OR c.dateAcqusition IS NOT NULL
  OR c.ipoDate IS NOT NULL
GROUP BY
  di.investorName
ORDER BY
  successful_exits DESC;