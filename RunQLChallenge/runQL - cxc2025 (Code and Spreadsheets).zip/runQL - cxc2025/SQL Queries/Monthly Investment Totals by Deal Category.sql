SELECT
  DATE_FORMAT (date, '%Y-%m') AS month,
  SUM(amount) AS total_amount,
  primaryTag
FROM
  deals
GROUP BY
  DATE_FORMAT (date, '%Y-%m'),
  primaryTag
ORDER BY
  month;