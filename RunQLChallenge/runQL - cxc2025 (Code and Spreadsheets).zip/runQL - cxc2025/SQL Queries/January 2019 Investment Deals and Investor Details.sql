SELECT
  d.id AS deal_id,
  d.companyName AS deal_company,
  di.investorName AS investor_name,
  di.investorCountry AS investor_country,
  d.investors AS all_investors,
  d.amount AS deal_amount
FROM
  deals d
  JOIN dealInvestor di ON d.id = di.dealId
WHERE
  d.date >= '2019-01-01'
  AND d.date < '2019-02-01';