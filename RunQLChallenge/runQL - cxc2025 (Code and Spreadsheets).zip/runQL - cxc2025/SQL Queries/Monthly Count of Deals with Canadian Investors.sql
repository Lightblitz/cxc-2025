SELECT
  DATE_FORMAT (d.date, '%Y-%m') AS month,
  COUNT(*) AS number_of_deals
FROM
  deals d
  JOIN dealInvestor di ON d.id = di.dealId
WHERE
  di.investorCountry = 'Canada'
GROUP BY
  month
ORDER BY
  month;