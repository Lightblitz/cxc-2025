SELECT
  DATE_FORMAT (date, '%Y-%m') AS month,
  SUM(amount) as total_amount,
  COUNT(amount) as num_transac
FROM
  deals
GROUP BY
  month
ORDER BY
  month;