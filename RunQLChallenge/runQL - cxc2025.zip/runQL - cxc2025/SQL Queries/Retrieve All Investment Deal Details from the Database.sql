SELECT
  *
FROM
  deals