SELECT
  DATE_FORMAT (d.date, '%Y-%m') AS month,
  i.city,
  SUM(d.amount) AS total_investment
FROM
  deals d
  JOIN dealInvestor di ON d.id = di.dealId
  JOIN investors i ON di.investorId = i.id
WHERE
  i.city IN (
    'Calgary',
    'Montreal',
    'Ottawa',
    'Toronto',
    'Vancouver',
    'Waterloo'
  )
GROUP BY
  month,
  i.city
ORDER BY
  i.city,
  month;