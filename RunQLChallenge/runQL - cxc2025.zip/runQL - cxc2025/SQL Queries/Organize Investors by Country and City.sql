SELECT
  *
FROM
  investors
ORDER BY
  country,
  city;