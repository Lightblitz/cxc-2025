WITH
  RankedInvestors AS ( -- Start CTE to rank investors
    SELECT
      di.roundType, -- Select the round type column from dealInvestor table
      di.investorName, -- Select the investor name column from dealInvestor table
      SUM(d.amount) AS totalInvestment, -- Calculate total investment amount
      COUNT(c.id) AS successfulExits, -- Count successful exits based on the acquired companies
      ROW_NUMBER() OVER (
        PARTITION BY
          di.roundType -- Partition data by round type to separate rankings per round type
        ORDER BY
          COUNT(c.id) DESC, -- Rank by descending count of successful exits
          SUM(d.amount) DESC -- Rank by descending total investment
      ) AS `rank` -- Assign a rank to each investor within its partition
    FROM
      dealInvestor di
      JOIN deals d ON di.dealId = d.id -- Join deals table on deal ID
      JOIN companies c ON di.companyId = c.id -- Join companies table on company ID
    WHERE
      c.acquiringCompany IS NOT NULL -- Include companies that have been acquired
      OR c.dateAcqusition IS NOT NULL -- Include companies with an acquisition date
      OR c.ipoDate IS NOT NULL
    GROUP BY
      di.roundType,
      di.investorName -- Group data by round type and investor
  )
SELECT
  roundType, -- Select round type from ranked investors
  investorName, -- Select investor name from ranked investors
  totalInvestment, -- Select total investment from ranked investors
  successfulExits -- Select successful exits from ranked investors
FROM
  RankedInvestors
WHERE
  `rank` <= 3;

-- Filter to include only top 3 investors per round type based on rank