WITH
  RankedInvestors AS ( -- Define a common table expression named RankedInvestors
    SELECT
      di.roundType, -- Select the type of investment round
      di.investorName, -- Select the name of the investor
      SUM(d.amount) AS totalInvestment, -- Compute the total investment amount by summing the deal amounts
      COUNT(c.id) AS successfulExits, -- Count the number of successful exits for each investor
      ROW_NUMBER() OVER ( -- Assign rank to each investor based on investment amount and exits
        PARTITION BY
          di.roundType -- Define partitioning by round type for each investor
        ORDER BY
          SUM(d.amount) DESC, -- Rank by descending total investment
          COUNT(c.id) DESC -- Rank by descending count of successful exits
      ) AS `rank`
    FROM
      dealInvestor di -- Select from dealInvestor to get investor details
      JOIN deals d ON di.dealId = d.id -- Join with deals to link investment amounts
      JOIN companies c ON di.companyId = c.id -- Join with companies to assess exits
    WHERE
      c.acquiringCompany IS NOT NULL -- Filter for acquired companies
      OR c.dateAcqusition IS NOT NULL -- Filter for companies with an acquisition date
      OR c.ipoDate IS NOT NULL
    GROUP BY
      di.roundType, -- Group results by round type
      di.investorName -- Group results by investor name
  )
SELECT
  roundType, -- Select the investment round type
  investorName, -- Select the name of the investor
  totalInvestment, -- Select the computed total investment amount
  successfulExits -- Select the computed count of successful exits
FROM
  RankedInvestors -- Retrieve from the ranked investors table expression
WHERE
  `rank` <= 10;

-- Filter to include only the top 10 ranked investors