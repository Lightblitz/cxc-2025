SELECT
  di.investorName,
  inv.country AS investorCountry,
  inv.city AS investorCity,
  COUNT(di.dealId) AS total_deals,
  SUM(
    CASE
      WHEN di.year = '2019' THEN 1
      ELSE 0
    END
  ) AS deals_2019,
  SUM(
    CASE
      WHEN di.year = '2020' THEN 1
      ELSE 0
    END
  ) AS deals_2020,
  SUM(
    CASE
      WHEN di.year = '2021' THEN 1
      ELSE 0
    END
  ) AS deals_2021,
  SUM(
    CASE
      WHEN di.year = '2022' THEN 1
      ELSE 0
    END
  ) AS deals_2022,
  SUM(
    CASE
      WHEN di.year = '2023' THEN 1
      ELSE 0
    END
  ) AS deals_2023,
  SUM(
    CASE
      WHEN di.year = '2024' THEN 1
      ELSE 0
    END
  ) AS deals_2024,
  SUM(
    CASE
      WHEN di.year = '2025' THEN 1
      ELSE 0
    END
  ) AS deals_2025
FROM
  dealInvestor di
  JOIN investors inv ON di.investorId = inv.id
GROUP BY
  di.investorName,
  inv.country,
  inv.city
ORDER BY
  total_deals DESC;