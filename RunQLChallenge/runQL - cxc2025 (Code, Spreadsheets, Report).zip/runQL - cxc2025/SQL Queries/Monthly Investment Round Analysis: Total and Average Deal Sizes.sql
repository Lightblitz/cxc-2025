SELECT
  roundType,
  DATE_FORMAT (date, '%Y-%m') AS month,
  COUNT(*) AS totalDeals,
  AVG(amount) AS averagedealsize
FROM
  deals
GROUP BY
  roundType,
  month;