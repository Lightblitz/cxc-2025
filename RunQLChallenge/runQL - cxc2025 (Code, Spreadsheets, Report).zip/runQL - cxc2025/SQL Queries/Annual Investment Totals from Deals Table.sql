SELECT
  SUM(amount) as total_amount,
  YEAR (date) as year
FROM
  deals
GROUP BY
  year