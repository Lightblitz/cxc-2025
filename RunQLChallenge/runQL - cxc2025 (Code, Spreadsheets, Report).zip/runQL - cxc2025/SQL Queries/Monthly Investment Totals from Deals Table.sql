SELECT
  DATE_FORMAT (date, '%Y-%m') AS month,
  SUM(amount) AS total_amount
FROM
  deals
GROUP BY
  DATE_FORMAT (date, '%Y-%m')
ORDER BY
  month;