SELECT
  roundType,
  DATE_FORMAT (date, '%Y-%m') AS month,
  SUM(amount) as total_amount,
  COUNT(amount) as num_investment
FROM
  deals
GROUP BY
  roundType,
  DATE_FORMAT (date, '%Y-%m');