SELECT
  DATE_FORMAT (d.date, '%Y-%m') AS month,
  c.primaryTag,
  SUM(d.amount) AS total_investment
FROM
  deals d
  JOIN companies c ON d.companyId = c.id
WHERE
  c.primaryTag IN (
    'FinTech',
    'SaaS',
    'AI',
    'Marketplace',
    'CleanTech'
  )
GROUP BY
  month,
  c.primaryTag
ORDER BY
  month,
  c.primaryTag;