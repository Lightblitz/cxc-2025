SELECT
  di.investorCountry,
  AVG(d.amount) AS average_deal_size
FROM
  dealInvestor di
  JOIN deals d ON di.dealId = d.id
GROUP BY
  di.investorCountry;