SELECT
  roundType,
  COUNT(*) AS totalDeals,
  AVG(amount) AS averagedealsize
FROM
  deals
GROUP BY
  roundType;