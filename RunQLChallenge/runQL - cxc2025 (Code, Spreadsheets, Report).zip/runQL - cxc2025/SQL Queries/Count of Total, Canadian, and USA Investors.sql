SELECT
  COUNT(DISTINCT id) AS total_investors,
  SUM(country = 'Canada') AS canadian_investors,
  SUM(country = 'USA') AS usa_investors
FROM
  investors;