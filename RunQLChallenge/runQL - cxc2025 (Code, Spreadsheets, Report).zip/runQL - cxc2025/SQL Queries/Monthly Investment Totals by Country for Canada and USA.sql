SELECT
  DATE_FORMAT (deals.date, '%Y-%m') AS month,
  SUM(deals.amount) AS total_amount,
  dealInvestor.investorCountry
FROM
  deals
  JOIN dealInvestor ON deals.companyId = dealInvestor.companyId
WHERE
  dealInvestor.investorCountry IN ('Canada', 'USA')
GROUP BY
  DATE_FORMAT (deals.date, '%Y-%m'),
  dealInvestor.investorCountry
ORDER BY
  month;